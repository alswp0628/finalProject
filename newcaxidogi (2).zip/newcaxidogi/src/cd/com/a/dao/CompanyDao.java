package cd.com.a.dao;

import cd.com.a.model.companyDto;

public interface CompanyDao {
	
	public int addCompany(companyDto company);

}
