package cd.com.a.dao;

public interface MyPageOrderDao {

}
