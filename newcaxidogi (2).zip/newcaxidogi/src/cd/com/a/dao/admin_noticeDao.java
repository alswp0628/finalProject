package cd.com.a.dao;

import cd.com.a.model.admin_noticeDto;

public interface admin_noticeDao {

	public boolean notice_insert(admin_noticeDto dto);
}
