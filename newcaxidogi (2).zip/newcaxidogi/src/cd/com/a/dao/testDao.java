package cd.com.a.dao;

public interface testDao {

}
