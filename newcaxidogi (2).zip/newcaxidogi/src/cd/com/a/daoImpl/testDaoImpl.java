package cd.com.a.daoImpl;

import cd.com.a.dao.testDao;

public class testDaoImpl implements testDao {

}
