package cd.com.a.service;

import cd.com.a.model.companyDto;

public interface CompanyService {
	public int addCompany(companyDto company);
}
