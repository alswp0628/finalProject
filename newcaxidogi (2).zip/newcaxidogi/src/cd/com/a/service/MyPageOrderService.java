package cd.com.a.service;

public interface MyPageOrderService {

}
