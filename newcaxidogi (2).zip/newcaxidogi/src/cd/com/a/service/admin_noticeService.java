package cd.com.a.service;

import cd.com.a.model.admin_noticeDto;

public interface admin_noticeService {

	public boolean notice_insert(admin_noticeDto dto);
}
