package cd.com.a.serviceImpl;

import cd.com.a.service.testService;

public class testServiceImpl implements testService {

}
